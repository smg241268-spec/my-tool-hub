import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {handle} from './api/index.js';
const root=path.resolve('public');
http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://localhost:3000');if(url.pathname==='/api'){
 const chunks=[];for await(const c of req)chunks.push(c);const request=new Request(url,{method:req.method,headers:req.headers,body:['GET','HEAD'].includes(req.method)?undefined:Buffer.concat(chunks)});const r=await handle(request);res.writeHead(r.status,Object.fromEntries(r.headers));res.end(Buffer.from(await r.arrayBuffer()));return;}
 const file=path.resolve(root,'.'+decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname));if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}const bytes=await fs.readFile(file);res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html');res.end(bytes);
 }catch{res.writeHead(404);res.end('Not found');}}).listen(3000,()=>console.log('http://localhost:3000'));
